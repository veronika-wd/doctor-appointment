<?php
/**
 * Plugin Name: Doctor Appointment
 * Description: Плагин для записи на приём к врача с возможностью редактирования и удаления.
 * Version: 1.2
 * Author: Ваше Имя
 * Text Domain: doctor-appointment
 */

defined('ABSPATH') or die('No script kiddies please!');

// Подключение админки
require_once plugin_dir_path(__FILE__) . 'admin/appointments-list.php';

// Хуки
register_activation_hook(__FILE__, 'dap_create_db');
add_action('init', 'dap_handle_form');
add_shortcode('doctor_appointment_form', 'dap_form_shortcode');
add_action('wp_ajax_dap_edit_appointment', 'dap_edit_appointment');
add_action('wp_ajax_dap_delete_appointment', 'dap_delete_appointment');
add_action('wp_ajax_nopriv_dap_edit_appointment', 'dap_edit_appointment');
add_action('wp_ajax_nopriv_dap_delete_appointment', 'dap_delete_appointment');


// === Создание таблицы ===
function dap_create_db() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        doctor_name tinytext NOT NULL,
        patient_name tinytext NOT NULL,
        patient_phone varchar(20) NOT NULL,
        appointment_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}


// === Обработка формы ===
function dap_handle_form() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dap_submit'])) {
        // Включите отладку: проверьте wp-config.php → WP_DEBUG_LOG = true
        error_log('📝 [DAP] Форма получена: ' . print_r($_POST, true));

        global $wpdb;
        $table_name = $wpdb->prefix . 'appointments';

        $doctor_name = sanitize_text_field($_POST['doctor_name'] ?? '');
        $patient_name = sanitize_text_field($_POST['patient_name'] ?? '');
        $patient_phone = sanitize_text_field($_POST['patient_phone'] ?? '');
        $date = sanitize_text_field($_POST['date'] ?? '');
        $time = sanitize_text_field($_POST['time'] ?? '');

        // Формат: "2025-11-26 14:30:00"
        $appointment_date = '';
        if ($date && $time) {
            $appointment_date = $date . ' ' . $time . ':00';
        }

        // Валидация
        if (empty($doctor_name) || empty($patient_name) || empty($patient_phone) || empty($appointment_date)) {
            error_log('❌ [DAP] Ошибка: одно из полей пустое');
            return;
        }

        // Вставка
        $result = $wpdb->insert($table_name, [
            'doctor_name'       => $doctor_name,
            'patient_name'      => $patient_name,
            'patient_phone'     => $patient_phone,
            'appointment_date'  => $appointment_date,
        ]);

        if ($result === false) {
            error_log('❌ [DAP] Ошибка БД: ' . $wpdb->last_error);
            return;
        }

        error_log('✅ [DAP] Запись успешно добавлена');

        wp_redirect(add_query_arg('dap_success', '1', home_url()));
        exit;
    }
}


// === Шорткод формы ===
function dap_form_shortcode() {
    $output = '';
    if (isset($_GET['dap_success']) && $_GET['dap_success'] === '1') {
        $output = '<div class="dap-success" style="padding:10px; background:#d4edda; color:#155724; margin:10px 0;">✅ Ваша запись успешно создана!</div>';
    }

    ob_start(); ?>
<form method="POST" class="dap-form" id="appointment-form">
  <label for="doctor">Выберите врача:</label>
  <select id="doctor" name="doctor_name" required>
    <option value="">— Выберите —</option>
    <option value="Доктор 1">Доктор 1</option>
    <option value="Доктор 2">Доктор 2</option>
  </select>

  <label for="date">Выберите дату:</label>
  <input type="date" id="date" name="date" required>

  <label for="time">Выберите время:</label>
  <input type="time" id="time" name="time" required>

  <label for="name">Ваше имя:</label>
  <input type="text" id="name" name="patient_name" required>

  <label for="phone">Ваш телефон:</label>
  <input type="tel" id="phone" name="patient_phone" required>

  <input type="hidden" name="dap_submit" value="1">
  <button type="submit" style="margin-top:10px; padding:8px 16px; background:#0073aa; color:white; border:none; cursor:pointer;">Записаться</button>
</form>
    <?php
    return $output . ob_get_clean();
}


// === AJAX: редактирование ===
function dap_edit_appointment() {
    check_ajax_referer('dap_nonce', 'nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    
    $id = intval($_POST['id']);
    $doctor_name = sanitize_text_field($_POST['doctor_name'] ?? '');
    $patient_name = sanitize_text_field($_POST['patient_name'] ?? '');
    $patient_phone = sanitize_text_field($_POST['patient_phone'] ?? '');
    $date = sanitize_text_field($_POST['date'] ?? '');
    $time = sanitize_text_field($_POST['time'] ?? '');
    
    $appointment_date = $date && $time ? $date . ' ' . $time . ':00' : '';

    $result = $wpdb->update($table_name, [
        'doctor_name'       => $doctor_name,
        'patient_name'      => $patient_name,
        'patient_phone'     => $patient_phone,
        'appointment_date'  => $appointment_date,
    ], ['id' => $id]);

    if ($result !== false) {
        wp_send_json_success();
    } else {
        wp_send_json_error('Ошибка обновления');
    }
}


// === AJAX: удаление ===
function dap_delete_appointment() {
    check_ajax_referer('dap_nonce', 'nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    
    $id = intval($_POST['id']);
    $result = $wpdb->delete($table_name, ['id' => $id]);
    
    if ($result) {
        wp_send_json_success();
    } else {
        wp_send_json_error('Ошибка удаления');
    }
}


// === Подключение скриптов на сайте ===
function dap_enqueue_scripts() {
    wp_enqueue_style('dap-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('dap-script', plugin_dir_url(__FILE__) . 'js/dap_script.js', ['jquery'], null, true);
    wp_localize_script('dap-script', 'dap_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('dap_nonce')
    ]);
}
add_action('wp_enqueue_scripts', 'dap_enqueue_scripts');


// === Подключение скриптов в админке ===
function dap_admin_enqueue_scripts($hook) {
    if ('toplevel_page_dap-appointments' !== $hook) return;
    wp_enqueue_script('dap-admin-script', plugin_dir_url(__FILE__) . 'js/dap_script.js', ['jquery'], null, true);
    wp_localize_script('dap-admin-script', 'dap_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('dap_nonce')
    ]);
}
add_action('admin_enqueue_scripts', 'dap_admin_enqueue_scripts');