<?php
add_action('admin_menu', 'dap_admin_menu');
function dap_admin_menu() {
    add_menu_page(
        'Записи к врачу',
        'Записи к врачу',
        'manage_options',
        'dap-appointments',
        'dap_appointments_page',
        'dashicons-calendar-alt'
    );
}

function dap_appointments_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    $appointments = $wpdb->get_results("SELECT * FROM $table_name ORDER BY appointment_date ASC");

    echo '<div class="wrap">';
    echo '<h1>Записи к врачу</h1>';

    if (empty($appointments)) {
        echo '<p>Нет записей.</p>';
    } else {
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>ID</th><th>Врач</th><th>Пациент</th><th>Телефон</th><th>Дата и время</th><th>Действия</th></tr></thead><tbody>';

        foreach ($appointments as $appt) {
            echo '<tr id="appointment-' . esc_attr($appt->id) . '">';
            echo '<td>' . esc_html($appt->id) . '</td>';
            echo '<td>' . esc_html($appt->doctor_name) . '</td>';
            echo '<td>' . esc_html($appt->patient_name) . '</td>';
            echo '<td>' . esc_html($appt->patient_phone) . '</td>';
            echo '<td>' . esc_html($appt->appointment_date) . '</td>';
            echo '<td>';
            echo '<button class="button dap-edit-btn" 
                data-id="' . esc_attr($appt->id) . '"
                data-doctor="' . esc_attr($appt->doctor_name) . '"
                data-patient="' . esc_attr($appt->patient_name) . '"
                data-phone="' . esc_attr($appt->patient_phone) . '"
                data-date="' . esc_attr($appt->appointment_date) . '">Редактировать</button> ';
            echo '<button class="button button-danger dap-delete-btn" data-id="' . esc_attr($appt->id) . '">Удалить</button>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }
    echo '</div>';
}