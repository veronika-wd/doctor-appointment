jQuery(document).ready(function($) {
    // Редактирование
    $(document).on('click', '.dap-edit-btn', function() {
        const id = $(this).data('id');
        const doctor = prompt("Имя врача:", $(this).data('doctor'));
        const patient = prompt("Имя пациента:", $(this).data('patient'));
        const phone = prompt("Телефон:", $(this).data('phone'));

        const fullDate = $(this).data('date');
        let datePart = '', timePart = '';
        if (fullDate) {
            const parts = fullDate.split(' ');
            datePart = parts[0] || '';
            timePart = (parts[1] || '').substring(0, 5);
        }

        const date = prompt("Дата (ГГГГ-ММ-ДД):", datePart);
        const time = prompt("Время (ЧЧ:ММ):", timePart);

        if (doctor && patient && phone && date && time) {
            $.post(dap_ajax.ajax_url, {
                action: 'dap_edit_appointment',
                id: id,
                doctor_name: doctor,
                patient_name: patient,
                patient_phone: phone,
                date: date,
                time: time,
                nonce: dap_ajax.nonce
            }, function(response) {
                if (response.success) {
                    alert('Запись обновлена!');
                    location.reload();
                } else {
                    alert('Ошибка: ' + response.data);
                }
            });
        }
    });

    // Удаление
    $(document).on('click', '.dap-delete-btn', function() {
        if (!confirm('Удалить запись?')) return;
        const id = $(this).data('id');
        $.post(dap_ajax.ajax_url, {
            action: 'dap_delete_appointment',
            id: id,
            nonce: dap_ajax.nonce
        }, function(response) {
            if (response.success) {
                alert('Запись удалена!');
                $('#appointment-' + id).fadeOut();
            } else {
                alert('Ошибка: ' + response.data);
            }
        });
    });
});